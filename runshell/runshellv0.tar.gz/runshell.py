# Copyright (C) USC/ISI 2013  
# This software is licensed under the GPLv3 license, included in
# ./GPLv3-LICENSE.txt in the source distribution

import logging
from magi.util.distributions import *
from magi.util.agent import DispatchAgent, agentmethod
from subprocess import check_output  

log = logging.getLogger(__name__)

def getAgent(**args):
       agent = RunShell()
       # If execargs are specified in the agent description, 
       # they can be used to overide default configuration 
       agent.setConfiguration(None,**args)
       return agent


class RunShell(DispatchAgent):
	"""
            Runs the specified script in a shell 
	"""
	def __init__(self):
                DispatchAgent.__init__(self)
		self.path = ''


        @agentmethod() 
        def execute(self, msg):

                log.info('startscript called' )

                cmd = []
                cmd.extend([str(self.path)])

                log.info('Running cmd: %s' % cmd)
                log.info('Output from %s' % cmd )
                log.info(check_output(cmd, shell=True))

                return True

