
import logging
import subprocess
import time
from sqlalchemy import Column, String, Float, Integer

from magi.util.agent import agentmethod, ReportingDispatchAgent
from magi.util.recording import DBase, Record, RecordingSession
from magi.testbed import testbed


log = logging.getLogger(__name__)

# GTL - I cannot track down why this import is failing when loading the agent. 
# in orde to make much needed progress, I'm just inserting the file in here and
# using it directly. This is very poor. FIX
# from magi.modules.nodeStats.foo import RuntimeStatsCollector, getRuntimeStatsCollector
################################ RuntimeStatsCollector.py #########################

# import logging
# import subprocess
from platform import platform
# 
# log = logging.getLogger(__name__)

class PlatformNotSupportedException(Exception):
    pass


def getRuntimeStatsCollector():
    '''Return an instance of a CPU reporter based on the platform this is executing on.'''
    if platform().lower().startswith('linux'):
        return LinuxRuntimeStatsCollector()

    raise PlatformNotSupportedException(platform())


class RuntimeStatsCollector(object):
    '''base class API for repoting on CPU usage.'''

    def __init__(self):
        pass

    def getCpuUsage(self):
        pass

    def getLoadAverage(self):
        pass


class LinuxRuntimeStatsCollector(RuntimeStatsCollector):
    def __init__(self):
        self.stats_prev = dict()
        self._readstats(self.stats_prev)


    def getCpuUsage(self):
        '''returns % of cpu time spent working (vs. idle) since getCpuUsage was last called.'''
        stats_now = dict()
        self._readstats(stats_now)
        total_jiffies = stats_now['total'] - self.stats_prev['total']
        work_jiffies = stats_now['work'] - self.stats_prev['work']
        return (float(work_jiffies) / float(total_jiffies)) * 100.0


    def getLoadAverage(self):
        '''return a 4-tuple of number of processes for 1 minute, 5 minutes, 15 minutes, and total 
        number currently running.'''
        # /proc/loadav is 5 numbers: load average @ 1 minute, 5 minutes, 15 minutes, runnable tasks, total procs.
        load_avg = subprocess.Popen(['cat','/proc/loadavg'], stdout=subprocess.PIPE).communicate()[0].split()
        return float(load_avg[0]), float(load_avg[1]), float(load_avg[2]), int(load_avg[4])


    def _readstats(self, stats):
        # sample 
        # 'cpu  5849 0 2211 1704105 1916 0 32 0 0 0'
        cpu_stats = subprocess.Popen(['cat', '/proc/stat'], stdout=subprocess.PIPE).communicate()[0].split('\n')[0].split()
        # we store more than we currently report on
        cpu_stats = [int(x) for x in cpu_stats[1:]]
        stats['user'] = cpu_stats[1]
        stats['nice'] = cpu_stats[2]
        stats['system'] = cpu_stats[3]
        stats['idle'] = cpu_stats[4]
        stats['iowait'] = cpu_stats[5]
        stats['total'] = sum(cpu_stats[1:5])
        stats['work'] = sum(cpu_stats[1:3])


# if __name__ == "__main__":
#     import time
#     stats = getRuntimeStatsCollector()
#     while True:
#         print 'time: %s' % time.ctime(time.time())
#         print 'load average: %f, %f, %f, %d' % stats.getLoadAverage()
#         print 'cpu usage: %s%%' % stats.getCpuUsage()
#         time.sleep(3.0)

######################### RuntimeStatsCollector.py EOF #########################


def getAgent():
    return NodeStatsReporter()


if 'NodeInfo' not in locals():
    class NodeInfo(DBase, Record):
        hostname = Column(String)
        experiment = Column(String)
        project = Column(String)
        is_container = Column(Integer) 
        experiment_description = Column(String)
        node_description = Column(String)


if 'RuntimeStats' not in locals():
    class RuntimeStats(DBase, Record):
        cpu_usage = Column(Float)           # current CPU % for all cores
        load_average_1 = Column(Integer)    # load average (number of processes) at 1, 5, and 15 minutes.
        load_average_5 = Column(Integer)
        load_average_15 = Column(Integer)
        load_average_total = Column(Integer)


class NodeStatsReporter(ReportingDispatchAgent):
    """
        Agent which records general information about a node. There is a single table which is staic information
        and a dynamic table of CPU information. 
    """
    table_class = RuntimeStats

    def __init__(self, *args, **kwargs):
        ReportingDispatchAgent.__init__(self, *args, **kwargs)
        self.runtime_info_collector = None
        self.active = False
        self.interval = 10
        self.truncate = True

        # Free form description of test run elements.
        self.nodeDescription = ''
        self.experimentDescription = ''

    def periodic(self, now):
        if self.active:
            cpu = self.runtime_info_collector.getCpuUsage()
            la1, la5, la15, latotal = self.runtime_info_collector.getLoadAverage()
            self.session.add(self.table_class(
                timestamp=time.time(),
                cpu_usage=cpu,
                load_average_1=la1,
                load_average_5=la1,
                load_average_15=la1,
                load_average_total=latotal))
            self.session.commit()

        ret=int(self.interval) + now - time.time()
        return ret if ret > 0 else 0

            
    @agentmethod()
    def startCollection(self, msg):
        if not self.active:
            if not self.runtime_info_collector:
                try:
                    self.runtime_info_collector = getRuntimeStatsCollector()
                except PlatformNotSupportedException:
                    log.critical('This platform is not supported for gather runtime stats')
                    return False

                # Create static info table and create the single row
                log.info('killing and recreating static node info table')
                self.session = RecordingSession()
                NodeInfo.metadata.drop_all(self.session.bind, tables=[NodeInfo.__table__])
                NodeInfo.metadata.create_all(self.session.bind)
                entry = NodeInfo(timestamp=time.time(), 
                                 hostname=testbed.getNodeName(),
                                 experiment=testbed.getExperiment(), 
                                 project=testbed.getProject(),
                                 is_container=testbed.amAVirtualNode(), 
                                 experiment_description=self.experimentDescription, 
                                 node_description=self.nodeDescription)
                self.session.add(entry)
                self.session.commit()

            self.active = True
            if self.truncate:
                log.info('dropping and recreating DB table ' + self.table_class.__name__)
                self.table_class.metadata.drop_all(self.session.bind, tables=[self.table_class.__table__])
            self.table_class.metadata.create_all(self.session.bind)
            log.info('runtime stats collection started')
        else:
            log.warning('start collection requested, but collection is already active')
        # return True so that any defined trigger gets sent back to the orchestrator
        return True

    @agentmethod()
    def stopCollection(self, msg):
        self.active = False
        self.session.close()
        log.info('runtime stats collection stopped')
        # return True so that any defined trigger gets sent back to the orchestrator
        return True


    def confirmConfiguration(self):
        try:
            self.interval= int(self.interval)
        except ValueError:
            log.error('Unable to convert integer value to int: %s', self.interval)
            return False

        return True


if __name__ == "__main__":
    import time
    a = getAgent()
    stats = getRuntimeStatsCollector()
    while True:
        print 'time: %s' % time.ctime(time.time())
        print 'load average: %f, %f, %f, %d' % stats.getLoadAverage()
        print 'cpu usage: %s%%' % stats.getCpuUsage()
        time.sleep(2.5)

