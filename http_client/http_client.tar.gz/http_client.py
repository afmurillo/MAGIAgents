# Copyright (C) 2013 University of Southern California.
# This software is licensed under the GPLv3 license, included in
# ./GPLv3-LICENSE.txt in the source distribution

import logging
from magi.util.agent import TrafficClientAgent, agentmethod
from magi.util.distributions import *
from magi.util.software import requireSoftware
from subprocess import call

log = logging.getLogger(__name__)

def getAgent(**args):
       agent = HttpAgent()
       # If execargs are specified in the agent description, 
       # they can be used to overide default configuration 
       agent.setConfiguration(None,**args)
       return agent


class HttpAgent(TrafficClientAgent):
	"""
		The wget http generator controls a set of wget clients that make HTTP requests to a set HTTP servers.
		Also look at TrafficClientAgent
	"""
	def __init__(self):
		TrafficClientAgent.__init__(self)

		# Can be support distribution function (look magi.util.distributions)
		self.sizes = '1000'
                self.url = "http://%s/getsize.py?length=%d"

		# SOCKS support
		self.useSocks = False
		self.socksServer = "localhost"
		self.socksPort = 5010
		self.socksVersion = 4
    
                

	def getCmd(self, dst):
            cmd = 'curl -o /dev/null -s -S -w data=%{url_effective},%{time_total},%{time_starttransfer},%{size_download},%{speed_download}\\n ' + self.url % (dst, eval(self.sizes))
            if self.useSocks:
			socks_cmd = "--proxy socks%d://%s:%d" % (int(self.socksVersion), self.socksServer, int(self.socksPort))
                        cmd = socks_cmd + cmd
            return cmd	
